enum TipoAeropuerto{
	Nacional, Internacional
}