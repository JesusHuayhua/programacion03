class Ciudad{
	private String nombre;
	public Ciudad(String nombre){
		this.nombre = nombre;
	}
	
	public String getNombre(){
		return nombre;
	}
}