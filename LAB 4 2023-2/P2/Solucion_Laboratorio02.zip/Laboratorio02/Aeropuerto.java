class Aeropuerto implements Consultable{
	private String nombre;
	private String direccion;
	private TipoAeropuerto tipoAeropuerto;
	private Ciudad ciudad;
	private Operadora operadora;
	
	public Aeropuerto(String nombre, String direccion, TipoAeropuerto tipoAeropuerto, Ciudad ciudad, Operadora operadora){
		this.nombre = nombre;
		this.direccion = direccion;
		this.tipoAeropuerto = tipoAeropuerto;
		this.ciudad = ciudad;
		this.operadora = operadora;
	}
	
	public String consultarDatos(){
		String cadena = "Aeropuerto: " + nombre + " - " + ciudad.getNombre() + " - " + tipoAeropuerto + "\n";
		cadena+= operadora.consultarDatos();
		return cadena;
	}
}