package org.pucp.airsoft.management.model;
public enum TipoAeropuerto{
	Nacional, Internacional
}