package org.pucp.airsoft.companies.model;
public interface Consultable{
	String consultarDatos();
}